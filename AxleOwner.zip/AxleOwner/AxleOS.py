import tkinter as tk
from tkinter import scrolledtext, messagebox
import os

class OSBuilderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("OS Builder and Tester")

        # Create a frame for user inputs
        self.input_frame = tk.Frame(root)
        self.input_frame.pack(padx=10, pady=10)

        # OS Name Input
        self.label_os_name = tk.Label(self.input_frame, text="OS Name:")
        self.label_os_name.grid(row=0, column=0, padx=5, pady=5)
        self.entry_os_name = tk.Entry(self.input_frame, width=30)
        self.entry_os_name.grid(row=0, column=1, padx=5, pady=5)

        # OS Version Input
        self.label_os_version = tk.Label(self.input_frame, text="OS Version:")
        self.label_os_version.grid(row=1, column=0, padx=5, pady=5)
        self.entry_os_version = tk.Entry(self.input_frame, width=30)
        self.entry_os_version.grid(row=1, column=1, padx=5, pady=5)

        # Bootloader Option
        self.label_bootloader = tk.Label(self.input_frame, text="Bootloader:")
        self.label_bootloader.grid(row=2, column=0, padx=5, pady=5)
        self.bootloader_option = tk.StringVar(value="Grub")
        self.option_bootloader = tk.OptionMenu(self.input_frame, self.bootloader_option, "Grub", "Lilo", "Syslinux")
        self.option_bootloader.grid(row=2, column=1, padx=5, pady=5)

        # Create and Test Buttons
        self.button_create = tk.Button(self.input_frame, text="Create OS", command=self.create_os)
        self.button_create.grid(row=3, column=0, padx=5, pady=5)
        self.button_test = tk.Button(self.input_frame, text="Test OS", command=self.test_os)
        self.button_test.grid(row=3, column=1, padx=5, pady=5)

        # Create a text area to display logs or results
        self.output_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, height=20, width=80)
        self.output_area.pack(padx=10, pady=10)
        self.output_area.config(state=tk.DISABLED)

    def log_message(self, message):
        self.output_area.config(state=tk.NORMAL)
        self.output_area.insert(tk.END, message + "\n")
        self.output_area.config(state=tk.DISABLED)
        self.output_area.yview(tk.END)

    def create_os(self):
        os_name = self.entry_os_name.get()
        os_version = self.entry_os_version.get()
        bootloader = self.bootloader_option.get()

        if not os_name or not os_version:
            messagebox.showwarning("Input Error", "Please provide both OS Name and OS Version.")
            return

        self.log_message(f"Starting OS creation process...")
        base_dir = os.path.join(os_name + "_" + os_version)
        
        # Check if the base directory already exists
        if os.path.exists(base_dir):
            self.log_message(f"Directory '{base_dir}' already exists. Aborting creation.")
            return

        # Create base directory
        os.makedirs(base_dir)
        self.log_message(f"Created base directory: {base_dir}")

        # Create subdirectories and files
        directories = ["bin", "etc", "home", "lib", "var", "boot", "usr"]
        for directory in directories:
            os.makedirs(os.path.join(base_dir, directory))
            self.log_message(f"Created directory: {os.path.join(base_dir, directory)}")
        
        # Create a simple bootloader file
        bootloader_file = os.path.join(base_dir, "boot", "bootloader.txt")
        with open(bootloader_file, "w") as f:
            f.write(f"Bootloader: {bootloader}")
        self.log_message(f"Created bootloader file: {bootloader_file}")

        # Create a basic configuration file
        config_file = os.path.join(base_dir, "etc", "os_config.txt")
        with open(config_file, "w") as f:
            f.write(f"OS Name: {os_name}\n")
            f.write(f"OS Version: {os_version}\n")
            f.write(f"Bootloader: {bootloader}\n")
        self.log_message(f"Created configuration file: {config_file}")

        self.log_message(f"OS '{os_name}' Version '{os_version}' created successfully.")

    def test_os(self):
        os_name = self.entry_os_name.get()
        os_version = self.entry_os_version.get()

        if not os_name or not os_version:
            messagebox.showwarning("Input Error", "Please create an OS before testing.")
            return

        base_dir = os.path.join(os_name + "_" + os_version)
        
        if not os.path.exists(base_dir):
            self.log_message(f"OS directory '{base_dir}' does not exist. Test failed.")
            return

        # Check if all necessary directories exist
        directories = ["bin", "etc", "home", "lib", "var", "boot", "usr"]
        for directory in directories:
            if not os.path.isdir(os.path.join(base_dir, directory)):
                self.log_message(f"Directory '{directory}' is missing in '{base_dir}'. Test failed.")
                return

        # Check if bootloader file exists
        bootloader_file = os.path.join(base_dir, "boot", "bootloader.txt")
        if not os.path.isfile(bootloader_file):
            self.log_message(f"Bootloader file '{bootloader_file}' is missing. Test failed.")
            return

        self.log_message(f"OS '{os_name}' Version '{os_version}' tested successfully. All components are present.")

if __name__ == "__main__":
    root = tk.Tk()
    app = OSBuilderApp(root)
    root.mainloop()
